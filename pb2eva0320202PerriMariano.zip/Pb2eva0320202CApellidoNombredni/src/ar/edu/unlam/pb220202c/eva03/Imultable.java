package ar.edu.unlam.pb220202c.eva03;

public interface Imultable {

	Boolean enInfraccion ();
}
